
package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.ParentDetail;
import com.repository.ParentDetailRepository;
@Service
public class ParentDetailService {
    @Autowired
    private ParentDetailRepository repository;

    public ParentDetail saveParentDetail(ParentDetail parentDetail) {
        return repository.save(parentDetail);
    }

    public List<ParentDetail> saveParentDetails(List<ParentDetail> parentDetails) {
        return repository.saveAll(parentDetails);
    }

    public List<ParentDetail> getParentDetail() {
        return repository.findAll();
    }

    public ParentDetail getParentDetailById(int id) {
        return repository.findById(id).orElse(null);
    }


    public String deleteParentDetail(int id) {
        repository.deleteById(id);
        return "parentDetail removed !! " + id;
    }

    public ParentDetail updateParentDetail(ParentDetail parentDetail) {
    	ParentDetail existingParentDetail = repository.findById(parentDetail.getId()).orElse(null);
        existingParentDetail.setName(parentDetail.getName());
        existingParentDetail.setEmail(parentDetail.getEmail());
        existingParentDetail.setContact(parentDetail.getContact());
        return repository.save(existingParentDetail);
    
    }

    public ParentDetail saveParentDetail(List<ParentDetail> parentDetail) {
        return null;
    }

    public ParentDetail updateParentDetail(List<ParentDetail> parentDetail) {
        return null;
    }
}
