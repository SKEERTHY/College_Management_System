package com.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Fee;

import com.repository.FeeRepository;

@Service
public class FeeService {
	@Autowired
    private FeeRepository feeRepository;

    public Fee addFee(Fee fee) {
        return feeRepository.save(fee);
    }

    public List<Fee> addAllFees(List<Fee> fees) {
        return  feeRepository.saveAll(fees);
    }

    public Fee getFeeByID(int id) {
        return feeRepository.findById(id).orElse(null);
    }

    public Fee updatefee(Fee fee) {
        Fee existingfee = feeRepository.findById(fee.getId()).orElse(null);
        System.out.println(fee);
        if(existingfee == null) {
            System.out.println("Fee not found");
            return  feeRepository.save(fee);
        }else  {
            existingfee.setId(fee.getId());
            existingfee.setCourse(fee.getCourse());
            existingfee.setAmount(fee.getAmount());
            feeRepository.save(existingfee);
        }
        return fee;
    }

    public boolean deleteFeeByID(int id) {
        Fee existingFee = feeRepository.getById(id);
        if(existingFee != null) {
            feeRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Fee> getAllFee() {
        return feeRepository.findAll();
    }

	public boolean deleteFeeByID1(int id) {
		// TODO Auto-generated method stub
		return false;
	}
}



   