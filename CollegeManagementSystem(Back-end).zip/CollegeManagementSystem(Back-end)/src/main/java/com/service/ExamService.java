
package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Exam;
import com.repository.ExamRepository;
@Service
public class ExamService {
    @Autowired
    private ExamRepository repository;

    public Exam saveExam(Exam exam) {
        return repository.save(exam);
    }

    public List<Exam> saveExam(List<Exam> exams) {
        return repository.saveAll(exams);
    }

    public List<Exam> getExams() {
        return repository.findAll();
    }

    public Exam getExamById(int id) {
        return repository.findById(id).orElse(null);
    }


    public String deleteExam(int id) {
        repository.deleteById(id);
        return "result removed !! " + id;
    }

    public Exam updateExam(Exam exam) {
    	Exam existingExam = repository.findById(exam.getId()).orElse(null);
        existingExam.setName(exam.getName());
        existingExam.setSubject(exam.getSubject());
        existingExam.setCourse(exam.getCourse());
        existingExam.setDate(exam.getDate());
        return repository.save(existingExam);
    
    }
}

	

