
package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Result;
import com.repository.ResultRepository;
@Service
public class ResultService {
    @Autowired
    private ResultRepository repository;

    public Result saveResult(Result result) {
        return repository.save(result);
    }

    public List<Result> saveResult(List<Result> results) {
        return repository.saveAll(results);
    }

    public List<Result> getResults() {
        return repository.findAll();
    }

    public Result getResultById(int id) {
        return repository.findById(id).orElse(null);
    }


    public String deleteResult(int id) {
        repository.deleteById(id);
        return "result removed !! " + id;
    }

    public Result updateResult(Result result) {
    	Result existingResult = repository.findById(result.getId()).orElse(null);
        existingResult.setName(result.getName());
        existingResult.setSubject(result.getSubject());
        existingResult.setResultss(result.getResultss());
        existingResult.setCourse(result.getCourse());
        
        return repository.save(existingResult);
    
    }
}

	

