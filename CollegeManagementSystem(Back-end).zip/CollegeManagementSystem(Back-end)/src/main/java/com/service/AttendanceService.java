package com.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Attendance;
import com.repository.AttendanceRepository;


@Service
public class AttendanceService {
	@Autowired
    private AttendanceRepository attendanceRepository;
	
    public Attendance addAttendance(Attendance attendance) {
        return attendanceRepository.save(attendance);
    }

    public List<Attendance> addAllAttendances(List<Attendance> attendances) {
        return  attendanceRepository.saveAll(getAllAttendance());
    }

    public Attendance getByID(int id) {
        return attendanceRepository.findById(id).orElse(null);
    }

    public Attendance updateAttendance(Attendance attendance) {
    	Attendance existingattendance = attendanceRepository.findById(attendance.getId()).orElse(null);
        System.out.println(attendance);
        if(existingattendance == null) {
            System.out.println("Attendancee not found");
            return  attendanceRepository.save(attendance);
        }else  {
            existingattendance.setId(attendance.getId());
            existingattendance.setCourse(attendance.getCourse());
            existingattendance.setName(attendance.getName());
            existingattendance.setSection(attendance.getSection());
            existingattendance.setReport(attendance.getReport());
            attendanceRepository.save(existingattendance);
        }
        return attendance;
    }

    public boolean deleteAttendanceByID(int id) {
        Attendance existingAttendance = attendanceRepository.getById(id);
        if(existingAttendance != null) {
            attendanceRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Attendance> getAllAttendance() {
        return attendanceRepository.findAll();
    }

	 
}


