package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Admission;
import com.repository.AdmissionRepository;
@Service
public class AdmissionService {
    @Autowired
    private AdmissionRepository repository;

    public Admission saveAdmission(Admission admission) {
        return repository.save(admission);
    }

    public List<Admission> saveAdmission(List<Admission> admissions) {
        return repository.saveAll(admissions);
    }

    public List<Admission> getAdmissions() {
        return repository.findAll();
    }

    public Admission getAdmissionById(int id) {
        return repository.findById(id).orElse(null);
    }


    public String deleteAdmission(int id) {
        repository.deleteById(id);
        return "admission removed !! " + id;
    }

    public Admission updateAdmission(Admission admission) {
    	Admission existingAdmission = repository.findById(admission.getId()).orElse(null);
        existingAdmission.setName(admission.getName());
        existingAdmission.setEmail(admission.getEmail());
        existingAdmission.setContact(admission.getContact());
        existingAdmission.setCourse(admission.getCourse());
        existingAdmission.setFee(admission.getFee());
        return repository.save(existingAdmission);
    
    }
}

	

