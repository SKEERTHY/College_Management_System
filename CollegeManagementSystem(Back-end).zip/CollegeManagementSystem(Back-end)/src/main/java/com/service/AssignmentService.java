
package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bean.Assignment;
import com.repository.AssignmentRepository;
@Service
public class AssignmentService {
    @Autowired
    private AssignmentRepository repository;

    public Assignment saveExam(Assignment assignment) {
        return repository.save(assignment);
    }

    public List<Assignment> saveExam(List<Assignment> assignment) {
        return repository.saveAll(assignment);
    }

    public List<Assignment> getAssignment() {
        return repository.findAll();
    }

    public Assignment getAssignmentById(int id) {
        return repository.findById(id).orElse(null);
    }


    public String deleteAssignment(int id) {
        repository.deleteById(id);
        return "result removed !! " + id;
    }

    public Assignment updateExam(Assignment assignment) {
    	Assignment existingAssignment = repository.findById(assignment.getId()).orElse(null);
        existingAssignment.setName(assignment.getName());
        existingAssignment.setSubject(assignment.getSubject());
        existingAssignment.setDate(assignment.getDate());
        return repository.save(existingAssignment);
    
    }

    public Assignment saveAssignment(List<Assignment> assignment) {
        return null;
    }

    public Assignment updateAssignment(Assignment assignment) {
        return null;
    }
}

	
