package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Book;
import com.repository.BookRepository;

@Service
public class BookService {
	 @Autowired
	    private BookRepository repository;

	    public String saveBook(Book book) {
	        repository.save(book);
	        return "Success";
	    }

	    public List<Book> saveBooks(List<Book> book) {
	        return repository.saveAll(book);
	    }

	    public List<Book> getBooks() {
	        return repository.findAll();
	    }

	    public Book getBookById(int id) {
	    	return repository.findById(id);
	    }


	    public String deleteBook(int id) {
	        repository.deleteById(id);
	        return "Book removed !! " + id;
	    }

	    public Book updateBook(Book book) {
	        Book existingBook = repository.findById(book.getId());
	        existingBook.setName(book.getName());
	        existingBook.setAuthor(book.getAuthor());
	        existingBook.setPrice(book.getPrice());
	        return repository.save(existingBook);
	    }


		
}
