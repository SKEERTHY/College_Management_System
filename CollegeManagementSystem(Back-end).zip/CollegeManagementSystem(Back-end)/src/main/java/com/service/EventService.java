package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Event;

import com.repository.EventRepository;

@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    public Event addEvent(Event event) {
        return eventRepository.save(event);
    }

    public List<Event> addAllEvents(List<Event> events) {
        return  eventRepository.saveAll(events);
    }

    public Event getEventByID(int id) {
        return eventRepository.findById(id).orElse(null);
    }

   

    public Event updateEvent(Event event) {
        Event existingevent = eventRepository.findById(event.getId()).orElse(null);
        System.out.println(event);
        if(existingevent == null) {
            System.out.println("Event not found");
            return  eventRepository.save(event);
        }else  {
            existingevent.setId(event.getId());
            existingevent.setName(event.getName());
            existingevent.setDate(event.getDate());
            eventRepository.save(existingevent);
        }
        return event;
    }

    public boolean deleteEventByID(int id) {
        Event existingevent = eventRepository.getById(id);
        if(existingevent != null) {
            eventRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Event> getAllEvent() {
        return eventRepository.findAll();
    }
}