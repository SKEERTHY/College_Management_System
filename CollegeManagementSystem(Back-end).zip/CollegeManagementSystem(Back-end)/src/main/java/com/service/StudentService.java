package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Student;
import com.repository.StudentRepository;

@Service
public class StudentService {
    @Autowired
    private StudentRepository repository;

    public String saveStudent(Student student) {
        repository.save(student);
        return "Success";
    }

    public List<Student> saveStudent(List<Student> students) {
        return repository.saveAll(students);
    }

    public List<Student> getStudents() {
        return repository.findAll();
    }

    public Student getStudentById(int id) {
        return repository.findById(id).orElse(null);
    }


    public String deleteStudent(int id) {
        repository.deleteById(id);
        return "student removed !! " + id;
    }

    public Student updateStudent(Student student) {
        Student existingStudent = repository.findById(student.getId()).orElse(null);
        existingStudent.setName(student.getName());
        existingStudent.setEmail(student.getEmail());
        existingStudent.setContact(student.getContact());
        existingStudent.setDept(student.getDept());
        existingStudent.setBatch(student.getBatch());
        return repository.save(existingStudent);
    }


	
}
