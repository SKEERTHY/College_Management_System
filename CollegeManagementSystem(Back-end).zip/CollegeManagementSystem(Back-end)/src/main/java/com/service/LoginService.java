package com.service;

import com.bean.Login;
import com.repository.LoginRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    @Autowired
    LoginRepository loginRepository;

    public String SignUp(Login login) {
        if(login.getTypeOfUser().equals("admin")) {
            return "You can't create admin account";
        }else {
       boolean res = loginRepository.existsById(login.getEmailid());
       if(res) {
           return "Account exist";
       }else {
           loginRepository.save(login);
           return "Account created successfully";
       }

            }
        }
    

    public String SignIn(Login login) {
        if(login.getTypeOfUser().equals("admin")) {
            if(loginRepository.checkLoginDetails(login.getEmailid(), login.getPassword())!=null) {
                return "admin login successfully";
            }else {
                return "failure";
        }
    }else {
        
        if(loginRepository.checkLoginDetails(login.getEmailid(), login.getPassword())!=null) {
            return "user login successfully";
        }else {
            return "failure";
        }
    }
    
}
}


