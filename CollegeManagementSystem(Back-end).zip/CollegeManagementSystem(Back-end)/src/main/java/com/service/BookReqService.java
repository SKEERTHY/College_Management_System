package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.BookReq;
import com.repository.BookReqRepository;

@Service
public class BookReqService {
	 @Autowired
	    private BookReqRepository repository;

	    public String saveBookReq(BookReq bookreq) {
	        repository.save(bookreq);
	        return "Success";
	    }

	    public List<BookReq> saveBooksReq(List<BookReq> bookreq) {
	        return repository.saveAll(bookreq);
	    }

	    public List<BookReq> getBookReqss() {
	        return repository.findAll();
	    }

	    public BookReq getBookReqById(int id) {
	        return repository.findById(id).orElse(null);
	    }


	    public String deleteBookReq(int id) {
	        repository.deleteById(id);
	        return "Book Request removed !! " + id;
	    }

	    public BookReq updateBookReq(BookReq bookreq) {
	        BookReq existingBookReq = repository.findById(bookreq.getId()).orElse(null);
	        existingBookReq.setBookName(bookreq.getBookName());
	        existingBookReq.setStudentName(bookreq.getStudentName());
	        existingBookReq.setStatus(bookreq.getStatus());
	        return repository.save(existingBookReq);
	    }

}
