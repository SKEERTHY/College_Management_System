package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Fee;
import com.service.FeeService;

@RestController
@RequestMapping("/fee")
public class FeeController {
	@Autowired
	
	private FeeService feeService;
	
	
	@PostMapping("/addFee")
    public Fee addFee(@RequestBody Fee fee) {
        return feeService.addFee(fee);
    }

    // Add more than 1 fee
    @PostMapping("/addFees")
    public List<Fee> addAllFees(@RequestBody List<Fee> fee) {
        return feeService.addAllFees(fee);
    }

  
    @GetMapping("/getFeeByID/{id}")
    public Fee getFeeById(@PathVariable int id) {
        return feeService.getFeeByID(id);
    }

    

    @PutMapping("/updateFee")
    public Fee updateFee(@RequestBody Fee fee) {
        return feeService.updatefee(fee);
    }

   
    @DeleteMapping("/deleteFeeById/{id}")
    public boolean deleteFeeByID(@PathVariable int id) {
        return feeService.deleteFeeByID(id);
    }

  
}
	


