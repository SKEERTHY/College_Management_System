package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Event;
import com.service.EventService;



@RestController
@RequestMapping("/event")
public class EventController {
	
	@Autowired
	
	private EventService eventService;
	
	
	@PostMapping("/addEvent")
    public Event addEvent(@RequestBody Event event) {
        return eventService.addEvent(event);
    }

	 @PostMapping("/addEvents")
	    public List<Event> addAllEvents(@RequestBody List<Event> event) {
	        return eventService.addAllEvents(event);
	    }
  
    @GetMapping("/getEventByID/{id}")
    public Event getEventById(@PathVariable int id) {
        return eventService.getEventByID(id);
    }

    

    @PutMapping("/updateEvent")
    public Event updateEvent(@RequestBody Event event) {
        return eventService.updateEvent(event);
    }

   
    @DeleteMapping("/deleteEventById/{id}")
    public boolean deleteEventByID(@PathVariable int id) {
        return eventService.deleteEventByID(id);
    }

  
}
	


