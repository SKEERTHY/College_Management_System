package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.bean.BookReq;
import com.service.BookReqService;

public class BookReqController {
	@Autowired
    private BookReqService service;

	 @PostMapping("/addBookReq")
	    public String addBookReq(@RequestBody BookReq bookreq) {
	        return service.saveBookReq(bookreq);
	    }

    

    @GetMapping("/bookreqs")
    public List<BookReq> findAllBookReqs() {
        return service.getBookReqss();
    }

    @GetMapping("/bookreqById/{id}")
    public BookReq findBookReqById(@PathVariable int id) {
        return service.getBookReqById(id);
    }
 

    @PutMapping("/update")
    public BookReq updateBookReq(@RequestBody BookReq bookreq) {
        return service.updateBookReq(bookreq);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteBookReq(@PathVariable int id) {
        return service.deleteBookReq(id);
    }
}
