
package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Exam;
import com.service.ExamService;

@RestController
@RequestMapping("exam")
@CrossOrigin()
public class ExamController {
	
	@Autowired
    private ExamService service;

    @PostMapping("/addExam")
    public Exam addExam(@RequestBody Exam exam) {
        return service.saveExam(exam);
    }

    @PostMapping("/addExams")
    public List<Exam> addExam(@RequestBody List<Exam> exam) {
        return service.saveExam(exam);
    }

    @GetMapping("/getExam")
    public List<Exam> findAllExams() {
        return service.getExams();
    }

    @GetMapping("examById/{id}")
    public Exam findExamById(@PathVariable int id) {
        return service.getExamById(id);
    }
 

    @PutMapping("/update")
    public Exam updateExam(@RequestBody Exam exam) {
        return service.updateExam(exam);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteExam(@PathVariable int id) {
        return service.deleteExam(id);
    }
}
