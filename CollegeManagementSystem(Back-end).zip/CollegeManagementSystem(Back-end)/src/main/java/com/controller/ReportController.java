


package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Report;
import com.service.ReportService;

@RestController
@RequestMapping("report")
@CrossOrigin()
public class ReportController {
	
	@Autowired
    private ReportService service;

    @PostMapping("/addReport")
    public Report addReport(@RequestBody Report report) {
        return service.saveReport(report);
    }

    @PostMapping("/addReports")
    public List<Report> addReport(@RequestBody List<Report> report) {
        return service.saveReport(report);
    }

    @GetMapping("/getReport")
    public List<Report> findAllReports() {
        return service.getReports();
    }

    @GetMapping("reportById/{id}")
    public Report findReportById(@PathVariable int id) {
        return service.getReportById(id);
    }
 

    @PutMapping("/update")
    public Report updateReport(@RequestBody Report report) {
        return service.updateReport(report);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteReport(@PathVariable int id) {
        return service.deleteReport(id);
    }
}
