

package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Admission;
import com.service.AdmissionService;

@RestController
@RequestMapping("admission")
@CrossOrigin()
public class AdmissionController {
	
	@Autowired
    private AdmissionService service;

    @PostMapping("/addAdmission")
    public Admission addAdmission(@RequestBody Admission admission) {
        return service.saveAdmission(admission);
    }

    @PostMapping("/addAdmissions")
    public List<Admission> addAdmission(@RequestBody List<Admission> admission) {
        return service.saveAdmission(admission);
    }

    @GetMapping("/getAdmission")
    public List<Admission> findAllAdmissions() {
        return service.getAdmissions();
    }

    @GetMapping("admissionById/{id}")
    public Admission findAdmissionById(@PathVariable int id) {
        return service.getAdmissionById(id);
    }
 

    @PutMapping("/update")
    public Admission updateAdmission(@RequestBody Admission admission) {
        return service.updateAdmission(admission);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteAdmission(@PathVariable int id) {
        return service.deleteAdmission(id);
    }
}
