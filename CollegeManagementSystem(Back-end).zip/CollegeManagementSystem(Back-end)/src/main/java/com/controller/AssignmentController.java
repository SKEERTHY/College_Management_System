package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Assignment;
import com.service.AssignmentService;

@RestController
@RequestMapping("assignment")
@CrossOrigin("*")
public class AssignmentController {
	
	@Autowired
    private AssignmentService service;

    

    @PostMapping("/addAssignment")
    public Assignment addAssignment(@RequestBody List<Assignment> assignment) {
        return service.saveAssignment(assignment);
    }

    @GetMapping("/getAssignment")
    public List<Assignment> findAllAssignment() {
        return service.getAssignment();
    }

    @GetMapping("AssignmentById/{id}")
    public Assignment findAssignmentById(@PathVariable int id) {
        return service.getAssignmentById(id);
    }
 

    @PutMapping("/update")
    public Assignment updateAssignment(@RequestBody Assignment assignment) {
        return service.updateAssignment(assignment);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteAssignment(@PathVariable int id) {
        return service.deleteAssignment(id);
    }
}
