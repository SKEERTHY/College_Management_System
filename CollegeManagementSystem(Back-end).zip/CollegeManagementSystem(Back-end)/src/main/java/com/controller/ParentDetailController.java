package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.ParentDetail;
import com.service.ParentDetailService;

@RestController
@RequestMapping("parentDetail")
@CrossOrigin()
public class ParentDetailController {
	
    @Autowired
    private ParentDetailService service;

    

    @PostMapping("/addParentDetail")
    public ParentDetail addParentDetail(@RequestBody ParentDetail parentDetails) {
        return service.saveParentDetail(parentDetails);
    }

    @PostMapping("/addParentDetails")
    public ParentDetail addParentDetail(@RequestBody List<ParentDetail> parentDetails) {
        return service.saveParentDetail(parentDetails);
    }


    @GetMapping("/getParentDetail")
    public List<ParentDetail> findAllParentDetail() {
        return service.getParentDetail();
    }

    @GetMapping("ParentDetailById/{id}")
    public ParentDetail findParentDetailById(@PathVariable int id) {
        return service.getParentDetailById(id);
    }
 

    @PutMapping("/update")
    public ParentDetail updateParentDetail(@RequestBody ParentDetail parentDetail) {
        return service.updateParentDetail(parentDetail);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteParentDetail(@PathVariable int id) {
        return service.deleteParentDetail(id);
    }
}

