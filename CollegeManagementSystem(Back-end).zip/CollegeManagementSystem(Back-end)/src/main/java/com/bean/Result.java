package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Result {
	
	@Id
	int id;
	String resultss;
	String name;
	String course;
	String subject;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCourse() {
		return course;
	}
	public void setCourse (String course) {
		this.course  = course;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject (String subject) {
		this.subject  = subject;
	}
	
	
	
	public String getResultss() {
		return resultss;
	}
	public void setResultss(String resultss) {
		this.resultss = resultss;
	}
	public Result(int id, String resultss, String name,  String course , String subject) {
		super();
		this.id = id;
		this.resultss = resultss;
		this.name = name;
		this.course = course;
		this.subject= subject;
		
	}
	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Result[id=" + id + ", resultss=" + resultss + ", name=" + name + ",   course=" + course + ", subject=" + subject 
				+ " ]";
	}
	
	
}

