package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Fee {
@Id
int id;
String course;
String amount;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCourse() {
	return course;
}
public void setCourse(String course) {
	this.course = course;
}
public String getAmount() {
	return amount;
}
public void setAmount(String amount) {
	this.amount = amount;
}
public Fee(int id, String course, String amount) {
	super();
	this.id = id;
	this.course = course;
	this.amount = amount;
}
public Fee() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Fee [id=" + id + ", course=" + course + ", amount=" + amount + "]";
}


}
