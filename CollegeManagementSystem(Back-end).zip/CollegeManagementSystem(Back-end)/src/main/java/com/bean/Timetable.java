package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Timetable {
	
	
		
		@Id
		int id;
		String name;
		String date;
		String course;
		String subject;
		
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}

		
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}

		
		
		public Timetable(int id, String course, String name, String date, String subject) {
			super();
			this.id = id;
			this.subject = subject;
			this.name = name;
			this.date = date;
			this.course = course;
			
		}
		public Timetable() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "Exam [id=" + id + ", subject=" + subject + ", name=" + name + ", date=" + date + ", course=" + course
					+ "]";
		}
		
		
	}


