package com.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookReq {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String bookName;
	String studentName;
	String status;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BookReq() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookReq(int id, String bookName, String studentName, String status) {
		super();
		this.id = id;
		this.bookName = bookName;
		this.studentName = studentName;
		this.status = status;
	}
	@Override
	public String toString() {
		return "BookReq [id=" + id + ", bookName=" + bookName + ", studentName=" + studentName + ", status=" + status
				+ "]";
	}
	
	
}
