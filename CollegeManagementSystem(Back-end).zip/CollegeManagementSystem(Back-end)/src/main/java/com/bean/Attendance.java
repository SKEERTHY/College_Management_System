package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Attendance {
@Id
	int id;
String name;
String course;
String section;
String report;

public String getReport() {
	return report;
}
public void setReport(String report) {
	this.report = report;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCourse() {
	return course;
}
public void setCourse(String course) {
	this.course = course;
}
public String getSection() {
	return section;
}
public void setSection(String section) {
	this.section = section;
}
public Attendance(int id, String name, String course, String section, String report) {
	super();
	this.id = id;
	this.name = name;
	this.course = course;
	this.section = section;
	this.report = report;
}
public Attendance() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Attendance [id=" + id + ", name=" + name + ", course=" + course + ", section=" + section + ", report="
			+ report + "]";
}
}