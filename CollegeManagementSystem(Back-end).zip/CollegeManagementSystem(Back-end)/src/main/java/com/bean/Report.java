
package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Report {
	
	@Id
	int id;
	String name;
	String course;
	String percentage;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCourse() {
		return course;
	}
	public void setCourse (String course) {
		this.course  = course;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	public Report(int id, String name, String percentage, String course) {
		super();
		this.id = id;
		this.name = name;
		this.percentage = percentage;
		this.course = course;
		
	}
	public Report() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Admission [id=" + id +  ", name=" + name + ", percentage=" + percentage + ", course=" + course
				 + "]";
	}
	
	
}
