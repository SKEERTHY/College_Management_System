
package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id 
	int id;
	String email;
	String name;
	String contact;
	String dept;
	String batch;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public Student(int id, String email, String name, String contact, String dept, String batch) {
		super();
		this.id = id;
		this.email = email;
		this.name = name;
		this.contact = contact;
		this.dept = dept;
		this.batch = batch;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", email=" + email + ", name=" + name + ", contact=" + contact + ", dept=" + dept
				+ ", batch=" + batch + "]";
	}
	
	
}
