package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bean.Fee;

public interface FeeRepository extends JpaRepository<Fee, Integer>{

}
