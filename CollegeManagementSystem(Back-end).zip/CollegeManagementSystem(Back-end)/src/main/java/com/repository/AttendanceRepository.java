package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bean.Attendance;

public interface AttendanceRepository extends JpaRepository<Attendance, Integer> {

}
