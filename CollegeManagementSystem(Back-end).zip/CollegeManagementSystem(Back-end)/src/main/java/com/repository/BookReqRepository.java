package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bean.BookReq;

@Repository
public interface BookReqRepository extends JpaRepository<BookReq,Integer> {
	BookReq findByBookName(String bookName);
}
