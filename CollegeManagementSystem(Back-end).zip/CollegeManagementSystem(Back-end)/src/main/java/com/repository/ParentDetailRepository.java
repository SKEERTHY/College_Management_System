package com.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bean.ParentDetail;

@Repository
public interface ParentDetailRepository extends JpaRepository<ParentDetail,Integer> {
    ParentDetail findByName(String name);
}