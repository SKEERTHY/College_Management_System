
package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bean.Admission;

@Repository
public interface AdmissionRepository extends JpaRepository<Admission,Integer> {
	Admission findById(int id);
}

